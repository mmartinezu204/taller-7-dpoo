package uniandes.dpoo.taller7.interfaz2;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;

public class VentanaPrincipal extends JFrame {
	private PanelSuperior panelSuperior;
	private PanelDerecha panelDerecha;
	private PanelAbajo panelAbajo;
	
	public VentanaPrincipal() {
		setTitle("Juego de LightsOut");
		setSize(new Dimension(500,400));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		panelSuperior = new PanelSuperior();
		add(panelSuperior, BorderLayout.NORTH);
		panelDerecha = new PanelDerecha();
		add(panelDerecha, BorderLayout.EAST);
		panelAbajo = new PanelAbajo();
		add(panelAbajo, BorderLayout.SOUTH);
		/*
		panelEntradas = new PanelEntradas(this);
		panelSalida= new PanelSalida();
		add(panelEntradas, BorderLayout.NORTH);
		add(panelSalida, BorderLayout.SOUTH);
		�*/
		
		setVisible(true);
	}
	public static void main(String[] args) {
		new VentanaPrincipal();
	}
}
