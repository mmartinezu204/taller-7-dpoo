package uniandes.dpoo.taller7.interfaz1;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
/*
import interfaz.PanelEntradas;
import interfaz.PanelSalida;
*/

public class VentanaPrincipal extends JFrame {
	
	public VentanaPrincipal() {
		setTitle("Juego de LightsOut");
		setSize(new Dimension(600,400));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		/*
		panelEntradas = new PanelEntradas(this);
		panelSalida= new PanelSalida();
		add(panelEntradas, BorderLayout.NORTH);
		add(panelSalida, BorderLayout.SOUTH);
		�*/
		
		setVisible(true);
	}
	public static void main(String[] args) {
		new VentanaPrincipal();
	}
}
