package uniandes.dpoo.taller7.interfaz4;

import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;


public class PanelSuperior extends JPanel implements ItemListener {
	private JLabel tamano;
	private JComboBox<String> tamabox;
	private JLabel dificultad;
	private JRadioButton facb;
	private JLabel facil;
	private JRadioButton medb;
	private JLabel medio;
	private JRadioButton difb;
	private JLabel dificil;
	private VentanaPrincipal padre;
	public PanelSuperior(VentanaPrincipal papa) {
		padre = papa;
		tamano = new JLabel("Tama�o");
		tamabox = new JComboBox<String>();
		tamabox.setSize(getPreferredSize());
		tamabox.addItem("5x5");
		tamabox.addItem("4x4");
		tamabox.addItem("6x6");
		dificultad = new JLabel("Dificultad");
		facb = new JRadioButton();
		facil = new JLabel("F�cil");
		medb = new JRadioButton();
		medio = new JLabel("Medio");
		difb = new JRadioButton();
		dificil = new JLabel("Dificil");
		setLayout(new FlowLayout());
		add(tamano);
		add(tamabox);
		tamabox.addItemListener(this);
		add(dificultad);
		add(facb);
		add(facil);
		add(medb);
		add(medio);
		add(difb);
		add(dificil);
	}
	public void itemStateChanged(ItemEvent e) {
        if (e.getSource()==tamabox) {
            String dimension = (String)tamabox.getSelectedItem();
            padre.cambiarDimension(dimension);
        }
	}	
}