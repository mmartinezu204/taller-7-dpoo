package uniandes.dpoo.taller7.interfaz4;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelDerecha extends JPanel implements ActionListener {
	private String NUEVO = "NUEVO";
	private String REINICIAR = "REINICIAR";
	private String TOP10 = "TOP-10";
	private String CAMBIAR = "CAMBIAR JUGADOR";
	private JButton nuevo;
	private JButton reiniciar;
	private JButton top10;
	private JButton cambiarj;
	private VentanaPrincipal padre;
	public PanelDerecha(VentanaPrincipal pa) {
		padre = pa;
		nuevo = new JButton(NUEVO);
		nuevo.setSize(40, 5);
		nuevo.setActionCommand(NUEVO);
		nuevo.addActionListener(this);
		reiniciar = new JButton(REINICIAR);
		reiniciar.setActionCommand(REINICIAR);
		reiniciar.addActionListener(this);
		reiniciar.setSize(40, 5);
		top10 = new JButton(TOP10);
		top10.setSize(40, 5);
		cambiarj = new JButton(CAMBIAR);
		cambiarj.setSize(40, 5);
		setLayout(new GridLayout(21,1)); // Para que quede centrado y con espacios entre
		add(new JLabel()); // Espacios vacios
		add(new JLabel()); // Espacios vacios
		add(new JLabel()); // Espacios vacios
		add(new JLabel()); // Espacios vacios
		add(new JLabel()); // Espacios vacios
		add(new JLabel()); // Espacios vacios
		add(new JLabel()); // Espacios vacios
		add(nuevo);
		add(new JLabel()); // Espacios vacios
		add(reiniciar);
		add(new JLabel()); // Espacios vacios
		add(top10);
		add(new JLabel()); // Espacios vacios
		add(cambiarj);
		add(new JLabel()); // Espacios vacios
		add(new JLabel()); // Espacios vacios
		add(new JLabel()); // Espacios vacios
		add(new JLabel()); // Espacios vacios
		add(new JLabel()); // Espacios vacios
		add(new JLabel()); // Espacios vacios
		add(new JLabel()); // Espacios vacios
	}
	public void actionPerformed(ActionEvent e) {
		String com = e.getActionCommand();
		if(com.equals(NUEVO)) {
			padre.nuevo();
		}
		if(com.equals(REINICIAR)) {
			padre.reiniciar();
		}
	}
}
