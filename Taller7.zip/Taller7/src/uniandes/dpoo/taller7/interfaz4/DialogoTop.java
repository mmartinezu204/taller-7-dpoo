package uniandes.dpoo.taller7.interfaz4;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.File;
import java.util.Collection;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import uniandes.dpoo.taller7.modelo.*;
import 

public class DialogoTop extends JDialog {
	private Top10 top10;
	public DialogoTop() {
		top10 = new Top10();
		Collection<RegistroTop10> registros = top10.darRegistros();
		setTitle("Top 10");
		setSize(new Dimension(500,400));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new GridLayout(11,1));
		add(new JLabel("# Nombre"));
		for(: ) {
			
		}
		setVisible(true);
	}
}
