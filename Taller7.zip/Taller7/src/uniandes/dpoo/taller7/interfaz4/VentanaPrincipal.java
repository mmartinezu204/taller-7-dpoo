package uniandes.dpoo.taller7.interfaz4;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;

public class VentanaPrincipal extends JFrame {
	private PanelSuperior panelSuperior;
	private PanelDerecha panelDerecha;
	private PanelAbajo panelAbajo;
	private PanelJuego panelJuego;
	private String dim;
	private String dimi;
	
	public VentanaPrincipal() {
		setTitle("Juego de LightsOut");
		setSize(new Dimension(500,400));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		panelSuperior = new PanelSuperior(this);
		add(panelSuperior, BorderLayout.NORTH);
		panelDerecha = new PanelDerecha(this);
		add(panelDerecha, BorderLayout.EAST);
		panelAbajo = new PanelAbajo();
		add(panelAbajo, BorderLayout.SOUTH);
		panelJuego = new PanelJuego("5x5");
		dimi = "5x5";
		add(panelJuego, BorderLayout.CENTER);
		
		setVisible(true);
	}
	public static void main(String[] args) {
		new VentanaPrincipal();
	}
	public void cambiarDimension(String dimension) {
		this.dim = dimension;
	}
	public void nuevo() {
		panelJuego.establecerDimension(dim);
		this.dimi = dim;
	}
	public void reiniciar() {
		panelJuego.establecerDimension(dimi);
	}
	
}
