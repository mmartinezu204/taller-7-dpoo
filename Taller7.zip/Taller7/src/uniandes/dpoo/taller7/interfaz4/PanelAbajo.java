package uniandes.dpoo.taller7.interfaz4;

import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelAbajo extends JPanel {
	private JLabel jugadas;
	private JTextField jug1;
	private JLabel jugador;
	private JTextField jug2;
	public PanelAbajo() {
		jugadas = new JLabel("  Jugadas: ");
		jug1 = new JTextField();
		jugador = new JLabel("  Jugador: ");
		jug2 = new JTextField();
		setLayout(new GridLayout(1,4));
		add(jugadas);
		add(jug1);
		add(jugador);
		add(jug2);
	}
}
