package uniandes.dpoo.taller7.interfaz3;

import java.awt.BorderLayout;
import javax.swing.*;
import java.awt.*;

import javax.swing.JPanel;

public class PanelJuego extends JPanel {
	private int dim;
	private int tam;
	private String dimen;
	
	public PanelJuego(String dimension) {
		establecerDimension(dimension);
	}
	
	public void establecerDimension(String dimension) {
		if (dimension == "5x5") {
			this.dim = 5;
			this.tam = 60;
		}
		else if (dimension == "4x4") {
			this.dim = 4;
			this.tam = 75;
		}
		else if (dimension == "6x6") {
			this.dim = 6;
			this.tam = 50;
		}
		repaint();
	}
	
	protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        pintarTablero(g,this.dim,this.tam);
    }
	
	public void pintarTablero(Graphics g, int dim, int tam) {
		Graphics2D g2d = (Graphics2D) g;
		for (int fila = 0; fila < dim; fila++) {
            for (int columna = 0; columna < dim; columna++) {
                // Cuadros del tablero
                g2d.setColor(Color.YELLOW);
                g2d.fillRect(columna * tam, fila * tam, tam, tam);

                // Lineas del tablero
                g2d.setColor(Color.BLACK);
                g2d.drawRect(columna * tam, fila * tam, tam, tam);
            }
        }
	}
}
